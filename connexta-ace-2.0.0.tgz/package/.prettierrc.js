module.exports = require("./prettierrc");
