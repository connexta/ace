module.exports = {
  singleQuote: true,
  trailingComma: 'es5',
  semi: false,
  endOfLine: 'lf',
}
